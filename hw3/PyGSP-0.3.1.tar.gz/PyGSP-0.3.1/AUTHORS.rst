=======
Credits
=======

Development Lead
----------------

* LTS2 Graph Task Force <LTS2Graph@groupes.epfl.ch>,
* Basile Châtillon <basile.chatillon@epfl.ch>,
* Alexandre Lafaye <alexandre.lafaye@epfl.ch>,
* Lionel Martin <lionel.martin@epfl.ch>,
* Nicolas Rod <nicolas.rod@epfl.ch>

Contributors
------------

None yet. Why not be the first?
