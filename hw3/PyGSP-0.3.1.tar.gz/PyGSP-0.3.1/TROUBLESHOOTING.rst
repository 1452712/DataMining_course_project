Troubleshooting
===============


Installation
------------

If you have trouble installing the package under an UNIX sytem, here are some hints.


Ubuntu / Debian
^^^^^^^^^^^^^^^

You will need the python-dev, liblapack-dev, libatlas-dev and gcc with gfortran extension as system packages in order to compile numpy and scipy.

Some versions of matplotlib have trouble finding sources, you'll maybe have to do some manual linking to install it.


General help
^^^^^^^^^^^^

You might find more help on the :ref:`About page <about>`.
